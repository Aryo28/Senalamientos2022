<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Senalamiento_image extends Model
{
    use HasFactory;

    protected $table = 'senalamientos_imagenes';
    public $timestamps = false;
}
